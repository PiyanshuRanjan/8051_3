

#include "MUG51.h"

#define print_function 

#define I2C_CLOCK                 13
#define I2C_SLAVE_ADDRESS         0x40
#define I2C_WR                    0
#define I2C_RD                    1

#define LOOP_SIZE                 1

void Init_I2C(void)
{
    MFP_P25_I2C0_SCL;
    P25_OPENDRAIN_MODE;          // Modify SCL pin to Open drain mode. don't forget the pull high resister in circuit
    MFP_P24_I2C0_SDA;
    P24_OPENDRAIN_MODE;          // Modify SDA pin to Open drain mode. don't forget the pull high resister in circuit

    SFRS = 0;
    /* Set I2C clock rate */
    I2C0CLK = I2C_CLOCK; 

    /* Enable I2C */
    set_I2C0CON_I2CEN;                                   
}

void I2C_Error(void)
{
   
  while(1);
}

void I2C_Write_Process(UINT8 u8DAT)
{
	
    unsigned char  u8Count;
    /* Write Step1 */
    set_I2C0CON_STA;                                    /* Send Start bit to I2C EEPROM */
    clr_I2C0CON_SI;
    while (!(I2C0CON&SET_BIT3));                                /*Check SI set or not  */
	      if (I2C0STAT != 0x08)                         /*Check status value after every step   */
        I2C_Error();
    
    /* Write Step2 */
    clr_I2C0CON_STA;                                    /*STA=0*/
    I2C0DAT = (I2C_SLAVE_ADDRESS | I2C_WR);
    clr_I2C0CON_SI;
    while (!(I2C0CON&SET_BIT3));                                /*Check SI set or not */
		    if (I2C0STAT != 0x18)              
        I2C_Error();

    /* Write Step3 */
    for (u8Count = 0; u8Count < LOOP_SIZE; u8Count++)
    {
        I2C0DAT = u8DAT;
        clr_I2C0CON_SI;
        while (!(I2C0CON&SET_BIT3)); 			/*Check SI set or not*/
				    if (I2C0STAT != 0x28)
            I2C_Error();
				
        u8DAT = ~u8DAT;
    }

    /* Write Step4 */
    set_I2C0CON_STO;
    clr_I2C0CON_SI;
    while (I2C0CON&SET_BIT4);                                /* Check STOP signal */
}
  

void main(void)
{

    Init_I2C();                                 /* initial I2C circuit  */
	  I2C_Write_Process(0x00);
	  I2C_Write_Process(0x00);
		I2C_Write_Process(0x11);
		I2C_Write_Process(0x11);
		I2C_Write_Process(0xAA);
		I2C_Write_Process(0x55); 	
    I2C_Write_Process(0xff);                          
    while (1);

}










/*void main (void)
{

  ALL_GPIO_PUSHPULL_MODE;
  while(1)
  {
    P3 = ~P3;
    SFRS = 2;
	  Timer2_Delay1ms(1000);
  }
}
*/


